#! @source_home
do
local _ = {
  SUDO = 000000000,
  sudoidforpanel = 00000000,
  cliidforpanel = 00000000,
        SUDO_ID = {00000000,00000000,00000000},
  sudoapibot = {00000000,00000000},
        Full_Sudo = {00000000,00000000,00000000},
        ChannelLogs= -00000000,
  token = '',
        TokenApibot = '',
        ChannelUsername = 'source_search',
        Channelforcejoin = '@source_search',
     Sudousernameapi = '',
        Channelusernameapi = 'source_search',
        Botusernameapi = '',
  salechannelbot = 'source_search',
        Pardakht = '',
        Botusernamelink = '',
        Sendpayiduser = 000000,
        apipanelbotuserid = 000000,
        Channelnameauto = 'ربات مدیریت گروه',
}
return _
end