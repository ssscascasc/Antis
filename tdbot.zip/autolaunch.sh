#! @source_home
COUNTER=1
while(true) do
./launch run
curl "https://api.telegram.org/bot613680863:AAF5ewJWa9e83aioRu5vqPoDr4aXTFCtYZY/sendmessage" -F "chat_id=159887854" -F "text=#NEWCRASH-#BOT-Reloaded-${COUNTER}-times"
let COUNTER=COUNTER+1 
done
#! @source_home
